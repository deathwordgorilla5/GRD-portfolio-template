$(document).ready(function() {
    // Interaction 1: Double the size of Box 1
    $(".project-1-category-card").click(function() {
        $(this).css({
            width: "300px",
            height: "480px"
        });
    });
    $(".project-2-category-card").click(function() {
        $(this).css({
            width: "300px",
            height: "480px"
        });
    });
    $(".project-3-category-card").click(function() {
        $(this).css({
            width: "300px",
            height: "480px"
        });
    });
    $(".project-4-category-card").click(function() {
        $(this).css({
            width: "300px",
            height: "480px"
        });
    });